import matplotlib.pyplot as plt
import numpy as np
import time


data = np.loadtxt('/Users/harshari/Desktop/SOSPictures/CSVdump/TimeY/SOS_CSV 12-12-20-15\51\53.csv ', delimiter=',')
# print the array
print(data)
